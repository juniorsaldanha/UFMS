#include <stdio.h>

int main()
{
    printf("Ola galera!\n");
    
    return 0;
}
